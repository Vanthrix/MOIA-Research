MOIA FINAL PUBLIC RESEARCH PACKET
Date: 17 August 2026

PRIMARY PUBLIC RECORD
Upload the consolidated Master PDF to Zenodo first.

SECONDARY PROJECT HOME
Create a GitHub repository and release the public package.

SECONDARY PREPRINT/DISCOVERY
Use OSF preprints/research projects as appropriate.

COLLABORATOR RECRUITMENT
Use the supplied lab/researcher email and contact researchers in experimental physics, optics/photonics, computational imaging, thermal measurement, magnetic measurement, and high-speed imaging.

PUBLIC CLAIM BOUNDARY
The package does not claim a new force, literal black-hole physics, or secure encryption. The unresolved blue-light/electrical-geometry observation is explicitly presented as a hypothesis requiring independent measurement.
