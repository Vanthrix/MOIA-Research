MOIA COMPLETE CONSOLIDATED RESEARCH PACKAGE
Date: 16 August 2026

FILES
1. MOIA_Complete_Consolidated_Research_Package.docx
2. MOIA_Complete_Consolidated_Research_Package.pdf
3. MOIA_Research_Package_README.txt

CONTENTS
- Executive scientific summary
- Research identity and scope
- Provenance/evidence boundary
- Apparatus architecture
- Master observation record
- Physics foundations and equations
- Claim-by-claim evidence matrix
- Central unresolved research question
- Controlled validation program
- Quantitative analysis pipeline
- Pass/fail criteria
- Full application map
- Publication strategy
- IP/disclosure strategy
- Black-hole analogy boundaries
- Limitations
- Public abstract
- Replication data sheet
- Claim status table

SCIENTIFIC POSITION
MOIA is presented as a multiphysics experimental platform. The strongest documented track is camera/display imaging and optical modulation. The blue-light/electrical-geometry/mechanical observation remains unresolved and is explicitly not presented as a new force. Cryptographic security and literal black-hole equivalence are not established.
